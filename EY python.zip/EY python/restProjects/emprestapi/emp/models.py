from django.db import models

# Create your models here.


class Employee(models.Model):

    salary = models.FloatField()
    doj = models.DateField()
    dob = models.DateField()
    emp_name = models.CharField(max_length=20)


class Department(models.Model):
    departmentName = models.CharField(max_length=20, unique=True)
    location = models.CharField(max_length=20)
