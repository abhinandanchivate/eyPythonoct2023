from django.shortcuts import render
from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser
# JSON==> object
from rest_framework import status
from rest_framework.decorators import api_view
from emp.serializers import EmployeeSerializer
from emp.models import Employee
# decorators : annotations : which are responsible for sharing the metadata
# Create your views here.
# writing rest api
# validation
# sharing right responsee @ right place : success rsponse or failure rsponse
# generating token
# what is microservice

# this function should be called when we will expect all employee details .
# /api/employee/


@api_view(['GET', 'POST', 'DELETE'])
def employee_list(request):
    if request.method == 'GET':
        # we should return all available employee details
        employees = Employee.objects.all()  # select * from employee

        if employees.count() > 0:
            # python objects to JSON ===> serializer
            employee_serializers = EmployeeSerializer(employees, many=True)
            return JsonResponse(employee_serializers.data, safe=False, status=status.HTTP_200_OK)
        else:
            return JsonResponse({'message': 'there is no record'}, status=status.HTTP_404_NOT_FOUND)
    elif request.method == 'POST':
        # we will share the data via request body and the same data we want to send it as a response.
        request_data = JSONParser().parse(request)
        employee_serializer = EmployeeSerializer(data=request_data)
        print(employee_serializer)
        if employee_serializer.is_valid():
            test = employee_serializer.save()
            print(test)
            return JsonResponse(employee_serializer.data, status=status.HTTP_201_CREATED)
        else:
            return JsonResponse(employee_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    elif request.method == 'DELETE':

        # if we will have the records then go for deleting the records else send the message stating records are not there.
        count = Employee.objects.all().delete()
        if count[0] > 0:
            return JsonResponse({'method': '{} records deleted'.format(count[0])}, status=status.HTTP_204_NO_CONTENT)
        else:
            return JsonResponse({'message': 'there is no record'}, status=status.HTTP_204_NO_CONTENT)
   # JsonResponse : to share the data interms of json .


@api_view(['GET', 'PUT', 'DELETE'])
def employee_detail(request, pk):
    try:
        employee = Employee.objects.get(pk=pk)
    except Employee.DoesNotExist:
        return JsonResponse({'message': 'employee does not exists'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        employee_serializer = EmployeeSerializer(employee)
        return JsonResponse(employee_serializer.data, safe=False, status=status.HTTP_200_OK)
    if request.method == 'DELETE':
        employee.delete()
        return JsonResponse({'message': 'employee was deleted'}, status=status.HTTP_204_NO_CONTENT)
# which will accept the name and will share the all employees who are having the same employee name.


@api_view(['GET'])
def employee_details_by_name(request, employeename):
    # select * from employee where emp_name = employeename
    # filter ===> where clause
    employee = Employee.objects.filter(emp_name=employeename)

    return JsonResponse(EmployeeSerializer(employee, many=True).data, safe=False, status=status.HTTP_200_OK)
