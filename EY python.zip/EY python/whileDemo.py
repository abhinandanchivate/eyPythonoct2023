max = 5
counter = 0

while counter <= max:
    print(counter)
    counter += 1
