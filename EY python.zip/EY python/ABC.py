from DepartmentsModule import Departments

print('hello from abhi')


def main():
    departments = Departments('abhi', 1, 1000, 100)
    print(departments.id)
    print(departments.name)


if __name__ == '__main__':
    main()
