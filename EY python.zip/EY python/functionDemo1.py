def hello():
    print('hello')
# this hello function will not accept any arguments and will not return anything.==> without arguments without return


hello()
