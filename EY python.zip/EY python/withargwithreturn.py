def number_check(num):
    if (num > 0):
        return 'positive'
    elif num < 0:
        return 'negative'
    else:
        return 'zero'


result = number_check(0)
print(result)
