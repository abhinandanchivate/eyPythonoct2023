

from EmployeeModule import Employee


class Departments(Employee):
    def __init__(self, name, emp_id, salary, department):
        # if we want to call / use intialized content from __init__ from the base class then call it directly using super() method.
        super().__init__(name, emp_id, salary, department)
        # we are initailizing the employee ka fields.
        print('hello from dept')
