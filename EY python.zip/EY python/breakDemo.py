# break :

for i in range(1, 10):
    if i == 7:
        print('inside loop {}'.format(i))
        continue
    print(i)
