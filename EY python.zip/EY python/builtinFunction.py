# sqrt pow : math : sqrt
import math
sqrt_result = math.sqrt(10)
print("%.2f" % sqrt_result)
print("{:.2f}".format(sqrt_result))

# even or odd number
# leap year
