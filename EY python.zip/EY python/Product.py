class Product:

    def __init__(self, productId, productName, tax, netPrice, inputCost, profit):
        self.productId = productId
        self.productName = productName
        self.tax = tax
        self.netPrice = netPrice
        self.inputCost = inputCost
        self.profit = profit

    def calculate_tax(self, tax_percentage):

        result = (tax_percentage * self.inputCost) / 100
        return result

    def calculate_profit(self):
        return self.profit - self.calculate_tax(self.tax)


product = Product(1, 'laptop', 10, 1000, 10000, 10)

tax_result = product.calculate_tax(10)

print(tax_result)

profit = product.calculate_profit()
print(profit)
