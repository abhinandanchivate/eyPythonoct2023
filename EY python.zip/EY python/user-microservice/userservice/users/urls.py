from django.urls import re_path
# end point mapping : endpoint ===> action part==> code which needs to be executed when a particular end point is called.
# end point mapping : endpoint ==> view ka method.
from users import views
urlpatterns = [
    # url patterns tha we will define those patterns must be unique.
    re_path(r'^api/users$', views.register_user),

    # [a-zA-Z0-9]
    # api/employee : (?pk/ id ==>number [0-9]+)
    # pk : path variable
    # [0-9] : range of digit
    # + : 1 or more
    # ? : zero or 1
    # * : zero or more
]
