from django.shortcuts import render
from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser
# JSON==> object
from rest_framework import status
from rest_framework.decorators import api_view


@api_view(['POST'])
def register_user(request):
    return JsonResponse({'message': 'hello world'})
