class Employee:
    # fields declation
    emp_id = 0
    emp_name = ''
    salary = 0
    age = 0

    def __init__(self, emp_id, emp_name, salary, age):
        # self = this ==> current object
        self.emp_id = emp_id
        self.emp_name = emp_name
        self.salary = salary
        self.age = age
        print('inside the init')

    # # can we define 2nd init :
    # def __init__(self):
    #     print('inside the init2')


# we don't have a concept of constructor
# we can use __init__ method to have simulation of constructor
employee = Employee(123, 'abhi', 100, 35)
# we created the object
employee2 = Employee(100, 'advik', 1000, 30)


print(f"{employee.emp_name} is having id {employee.emp_id}")

print(employee2)

#
